import { fetchBooksSuccess } from "../action/Book.action";
import {
    ADD_BOOK_ERROR,
    ADD_BOOK_LOADING,
    ADD_BOOK_SUCCESS,
    DELETE_BOOK_ERROR,
    DELETE_BOOK_SUCCESS,
    
    EDIT_BOOK_ERROR,
    EDIT_BOOK_SUCCESS,
    FETCH_BOOK_LOADING,
    FETCH_BOOK_SUCCESS
    
  } from "../action/types";

  const defaultState ={
      books:[],
     
 }
 const bookReducer =(state=defaultState,action)=>{
    switch(action.type)
    {
            case FETCH_BOOK_SUCCESS:
            return {...state,books:action.payload}
            
            default:return state;
    }
 }
 export default bookReducer;