import React, {Component} from 'react';
import {Text, View, Image, FlatList, TouchableOpacity} from 'react-native';
import { connect, Connect } from "react-redux";
class Category extends Component {
  constructor() {
    super();
   
  }
 

  render() {
    
    console.log("this.prop",this.props.book)
    const navigation = (price, name, url) => {
      this.props.navigation.navigate('ViewCard', {
              price: price,
        name: name,
        url: url,
      });
    };
    return (
      <View style={{height: '100%'}}>
        <View
          style={{
            marginHorizontal: 1,
            marginVertical: 1,
            width: '100%',
            height: '100%',
            justifyContent: 'center',
          }}>
          <FlatList
            numColumns={3}
            style={{height: '10%', padding: 10}}
            data={this.props.book}
            renderItem={({item, index}) => (
              <View style={{margin: 5, borderRadius: 2}}>
                <Image
                  source={{uri: item.url}}
                  style={{height: 100, width: 100}}
                />
                <Text style={{textAlign: 'center'}}>{item.name}</Text>
           
               
                <TouchableOpacity
                  style={{
                    backgroundColor: 'orange',
                    padding: 10,
                    borderRadius: 5,
                  }}
                  onPress={() => navigation(item.Price, item.name, item.url)}>
                  <Text style={{textAlign: 'center'}}>Add to cart</Text>
                </TouchableOpacity>
              </View>
            )}
          />
        </View>
      </View>
    );
  }
}

const mapStateToprops = (state) => {
  // console.log("tate",state)
  return {
   book:state.books || [],
 };
};
export default connect(mapStateToprops, null)(Category);


