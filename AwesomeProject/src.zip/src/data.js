export const Data=[
            {
          id: 0,
          name: 'apple',
          url: 'https://images.pexels.com/photos/102104/pexels-photo-102104.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
          price: 100,
         
        },
        {
          id: 1,
          name: 'orange',
          url: 'https://images.pexels.com/photos/161559/background-bitter-breakfast-bright-161559.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500',
          price: 100,
          
        },
        {
          id: 2,
          name: 'watermelon',
          url: 'https://images.pexels.com/photos/1313267/pexels-photo-1313267.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500',
          price: 200,
         
        },
        {
          id: 3,
          name: 'cherry',
          url: 'https://images.pexels.com/photos/35629/bing-cherries-ripe-red-fruit.jpg?auto=compress&cs=tinysrgb&h=750&w=1260',
          price: 300,
          
        },
        {
          id: 4,
          name: 'strawberry',
          url: 'https://images.pexels.com/photos/46174/strawberries-berries-fruit-freshness-46174.jpeg?auto=compress&cs=tinysrgb&h=750&w=1260',
          price: 400,
          
        },
        {
          id: 5,
          name: 'blueberry',
          url: 'https://images.pexels.com/photos/1395958/pexels-photo-1395958.jpeg?auto=compress&cs=tinysrgb&h=750&w=1260',
          price: 100,
          
        },
        {
          id: 6,
          name: 'Lime',
          url: 'https://images.pexels.com/photos/161573/background-water-breakfast-bright-161573.jpeg?auto=compress&cs=tinysrgb&h=750&w=1260',
          price: 500,
          
        },
        {
          id: 7,
          name: 'Avocado',
          url: 'https://images.pexels.com/photos/557659/pexels-photo-557659.jpeg?auto=compress&cs=tinysrgb&h=750&w=1260',
          Price: 200,
          
        },
        {
          id: 8,
          name: 'pineapple',
          url: 'https://images.pexels.com/photos/1161547/pexels-photo-1161547.jpeg?auto=compress&cs=tinysrgb&h=750&w=1260',
          Price: 100,
          
        },
        {
          id: 9,
          name: 'grape',
          url: 'https://images.pexels.com/photos/197907/pexels-photo-197907.jpeg?auto=compress&cs=tinysrgb&h=750&w=1260',
          Price: 500,
          
        },
        {
          id: 10,
          name: 'papaya',
          url: 'https://images.pexels.com/photos/1824354/pexels-photo-1824354.jpeg?auto=compress&cs=tinysrgb&h=750&w=1260',
          Price: 200,
          
        },
      ]   
        
