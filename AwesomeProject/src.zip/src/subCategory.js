import React, {Component} from 'react';
import {Text, View, Image,TouchableOpacity,} from 'react-native';
class ViewCard extends Component {
  Constructor() {
    Supper();
  }
  render() {
    const {name, url, price} = this.props.route.params;

    return (
      <View>
        <View style={{height: '70%'}}>
          <Image source={{uri: url}} style={{height: '100%', width: '100%'}} />
          <View style={{width: 150,flexDirection:'row'}}>
            <View>
              <Text
                style={{
                  fontWeight: 'bold',
                  marginHorizontal: 5,
                  marginVertical: 5,
                  fontSize: 20,
                }}>
                ProductName:
              </Text>
              <Text
                style={{
                  fontWeight: 'bold',
                  marginHorizontal: 5,
                  marginVertical: 5,
                  fontSize: 20,
                }}>
                Price:
              </Text>
            </View>
            <View>
            <Text
                style={{
                  fontWeight: 'bold',
                  marginHorizontal: 5,
                  marginVertical: 5,
                  fontSize: 20,
                }}>
                {name}
              </Text>
              <Text
                style={{
                  fontWeight: 'bold',
                  marginHorizontal: 5,
                  marginVertical: 5,
                  fontSize: 20,
              
                color:'black'
                }}>
                
               {price}
              </Text>
            </View>
            <View>
         
            </View>
          </View>
          <TouchableOpacity style={{backgroundColor:'orange',padding:5,margin:50,borderRadius:10}} >
              <Text style={{textAlign:'center'}}>Add to card</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }
}
export default ViewCard;
