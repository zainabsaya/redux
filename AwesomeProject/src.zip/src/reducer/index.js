import {combineReducers} from 'redux';
import books from './BookReducer';
export default combineReducers({
    booksData:books,
    })